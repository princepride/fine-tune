# test-strip-head > 2023-04-01 2:11pm
https://universe.roboflow.com/teststriphead/test-strip-head

Provided by a Roboflow user
License: CC BY 4.0

